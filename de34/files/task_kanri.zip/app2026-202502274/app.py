from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    jsonify
)

import os
import psycopg2
import psycopg2.extras

app = Flask(__name__)
app.secret_key = "secret-key"

@app.template_filter('formdatetime')
def formdatetime_filter(value):
    """datetimeオブジェクトを <input type="datetime-local"> 用の文字列に変換する"""
    if not value:
        return ""
    # 文字列で渡ってきた場合のハンドリング（必要に応じて）
    if isinstance(value, str):
        return value
    # datetimeオブジェクトを YYYY-MM-DDTHH:MM 形式に変換
    return value.strftime('%Y-%m-%dT%H:%M')


# -----------------------------
# DB接続
# -----------------------------
def get_db_connection():

    database_url = os.environ.get("DATABASE_URL")

    if not database_url:
        raise ValueError("環境変数 DATABASE_URL が設定されていません")

    return psycopg2.connect(database_url)


# -----------------------------
# トップページ
# -----------------------------
@app.route("/")
def index():

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            title,
            description,
            due_date,
            status,
            created_at
        FROM tasks
        WHERE deleted_at IS NULL
        ORDER BY created_at DESC
    """)

    tasks = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "index.html",
        tasks=tasks
    )


# -----------------------------
# タスク一覧
# -----------------------------
@app.route("/tasks")
def tasks_view():

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            title,
            description,
            due_date,
            status,
            created_at
        FROM tasks
        WHERE deleted_at IS NULL
        ORDER BY created_at DESC
    """)

    tasks = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "index.html",
        tasks=tasks
    )


# -----------------------------
# タスク追加
# -----------------------------
@app.route("/tasks/create", methods=["POST"])
def create_task():

    title = request.form.get("title")
    description = request.form.get("description")
    due_date = request.form.get("due_date")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO tasks (
            title,
            description,
            due_date,
            status
        )
        VALUES (%s, %s, %s, %s)
    """, (
        title,
        description,
        due_date if due_date else None,
        "pending"
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("タスクを追加しました")

    return redirect(url_for("index"))


# -----------------------------
# タスク完了
# -----------------------------
@app.route("/tasks/<int:task_id>/complete", methods=["POST"])
def complete_task(task_id):

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE tasks
        SET status = 'done'
        WHERE id = %s
    """, (
        task_id,
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("タスクを完了しました")

    return redirect(url_for("index"))


# -----------------------------
# タスク削除
# -----------------------------
@app.route("/tasks/<int:task_id>/delete", methods=["POST"])
def delete_task(task_id):

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE tasks
        SET deleted_at = now()
        WHERE id = %s
    """, (
        task_id,
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("タスクを削除しました")

    return redirect(url_for("index"))


# -----------------------------
# タスク編集画面
# -----------------------------
@app.route("/tasks/<int:task_id>/edit")
def edit_task(task_id):

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            title,
            description,
            due_date,
            status
        FROM tasks
        WHERE id = %s
    """, (
        task_id,
    ))

    task = cur.fetchone()

    cur.close()
    conn.close()

    return render_template(
        "task_edit.html",
        task=task
    )


# -----------------------------
# タスク更新
# -----------------------------
@app.route("/tasks/<int:task_id>/update", methods=["POST"])
def update_task(task_id):

    title = request.form.get("title")
    description = request.form.get("description")
    due_date = request.form.get("due_date")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE tasks
        SET
            title = %s,
            description = %s,
            due_date = %s
        WHERE id = %s
    """, (
        title,
        description,
        due_date if due_date else None,
        task_id
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("タスクを更新しました")

    return redirect(url_for("index"))


# -----------------------------
# 授業一覧
# -----------------------------
@app.route("/lessons")
def lessons_view():

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            lesson_name,
            instructor_name,
            weekday,
            start_time,
            end_time,
            location
        FROM lessons
        WHERE deleted_at IS NULL
        ORDER BY weekday, start_time
    """)

    lessons = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "lessons.html",
        lessons=lessons
    )


# -----------------------------
# 授業登録
# -----------------------------
@app.route("/lessons/create", methods=["POST"])
def create_lesson():

    lesson_name = request.form.get("lesson_name")
    instructor_name = request.form.get("instructor_name")
    weekday = request.form.get("weekday")
    start_time = request.form.get("start_time")
    end_time = request.form.get("end_time")
    location = request.form.get("location")

    conn = get_db_connection()

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO lessons (
            lesson_name,
            instructor_name,
            weekday,
            start_time,
            end_time,
            location
        )
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (
        lesson_name,
        instructor_name,
        weekday,
        start_time,
        end_time,
        location
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("授業を登録しました")

    return redirect(url_for("lessons_view"))


# -----------------------------
# カレンダー
# -----------------------------
@app.route("/calendar")
def calendar_view():

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            title,
            start_at,
            end_at,
            category,
            description
        FROM events
        ORDER BY start_at
    """)

    rows = cur.fetchall()

    events = []

    for row in rows:

        events.append({
            "title": row["title"],
            "start": row["start_at"].isoformat() if row["start_at"] else None,
            "end": row["end_at"].isoformat() if row["end_at"] else None
        })

    cur.close()
    conn.close()

    return render_template(
        "calendar.html",
        events=events
    )


# -----------------------------
# イベント追加
# -----------------------------
@app.route("/events/create", methods=["POST"])
def create_event():

    title = request.form.get("title")
    category = request.form.get("category")
    start_at = request.form.get("start_at")
    end_at = request.form.get("end_at")
    description = request.form.get("description")

    is_all_day = request.form.get("is_all_day") == "true"

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO events (
            title,
            category,
            start_at,
            end_at,
            description,
            is_all_day
        )
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (
        title,
        category,
        start_at,
        end_at,
        description,
        is_all_day
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("予定を追加しました")

    return redirect(url_for("calendar_view"))

# -----------------------------
# イベント編集
# -----------------------------
@app.route("/event/edit/<int:event_id>", methods=["POST"])
def edit_event(event_id):

    title = request.form.get("title")
    category = request.form.get("category")
    start_at = request.form.get("start_at")
    end_at = request.form.get("end_at")
    description = request.form.get("description")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        UPDATE events
        SET
            title = %s,
            category = %s,
            start_at = %s,
            end_at = %s,
            description = %s
        WHERE id = %s
    """, (
        title,
        category,
        start_at,
        end_at,
        description,
        event_id
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("予定を更新しました")

    return redirect(url_for("calendar_view"))

# -----------------------------
# イベント削除
# -----------------------------
@app.route("/event/delete/<int:event_id>", methods=["POST"])
def delete_event(event_id):

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        DELETE FROM events
        WHERE id = %s
    """, (
        event_id,
    ))

    conn.commit()

    cur.close()
    conn.close()

    flash("予定を削除しました")

    return redirect(url_for("calendar_view"))


# -----------------------------
# カレンダーAPI
# -----------------------------
@app.route("/api/events")
def api_events():

    conn = get_db_connection()

    cur = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    cur.execute("""
        SELECT
            id,
            title,
            start_at,
            end_at,
            is_all_day
        FROM events
        ORDER BY start_at
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    events = []

    for row in rows:
        events.append({
            "id": row["id"],
            "title": row["title"],
            "start": row["start_at"].isoformat(),
            "end": row["end_at"].isoformat() if row["end_at"] else None,
            "allDay": row["is_all_day"]
        })

    return jsonify(events)

# -----------------------------
# 起動
# -----------------------------
if __name__ == "__main__":

    port = int(os.environ.get("PORT", 3000))

    app.run(
        host="0.0.0.0",
        port=port
    )