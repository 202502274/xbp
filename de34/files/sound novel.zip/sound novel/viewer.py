import sys
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import xml.etree.ElementTree as ET
import os
import fitz  # PyMuPDF
from PIL import Image, ImageTk
import pygame  # 音楽再生用
import ctypes
import bisect
import urllib.request
import urllib.parse
import tempfile
import math  # ★追加：ピンチズームの距離計算用

try:
    # タスクバーのアイコンを強制適用するためのWindows用設定
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("mycompany.musicpdfviewer.1.0")
except Exception:
    pass

class MusicPDFViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("Sound Novel")
        self.root.geometry("950x950")

        # アイコンの設定
        if os.path.exists("app_icon.ico"):
            self.root.iconbitmap(default="app_icon.ico")

        # 変数の初期化
        self.doc = None
        self.file_path = ""        
        self.current_page = 0
        self.playlist = {}         
        self.playlist_pages = []  
        self.current_music = ""    
        self.is_paused = False       
        self.is_loading = False      
        self.resize_timer = None   

        # ★タッチ操作用の変数初期化
        self.touch_start_x = 0
        self.touch_start_y = 0
        self.last_pinch_dist = None

        # pygameのオーディオ機能を初期化
        pygame.mixer.init()

        # UIの構築
        self.create_widgets()

        # ウィンドウのサイズ変更イベント
        self.root.bind("<Configure>", self.on_resize)

        # キーボード操作（左キーで進む、右キーで戻る、スペースで一時停止）
        self.root.bind("<Left>", lambda e: self.next_page())       
        self.root.bind("<Right>", lambda e: self.prev_page())        
        self.root.bind("<space>", lambda e: self.toggle_play_pause())

        # ★キャンバスへのタッチ・ジェスチャーのバインド
        # Windowsのタッチパネルは、1本指ドラッグはB1-Motion、2本指ピンチはMouseWheelイベント等に変換されます
        self.canvas.bind("<Button-1>", self.on_touch_start)
        self.canvas.bind("<ButtonRelease-1>", self.on_touch_end)
        self.canvas.bind("<MouseWheel>", self.on_pinch_zoom)  # トラックパッド・2本指ズームの検知

        # ウィンドウを閉じるイベントの捕捉（終了時に栞を保存する）
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)


    def load_playlist_xml(self, xml_url):
        """PDFのキーワードから取得したURL（またはローカルパス）からXMLを解析する"""
        if not xml_url:
            print("警告: XMLのURLが指定されていません。音楽は再生されません。")
            return
            
        try:
            print(f"XMLプレイリストを読み込み中: {xml_url}")
            
            # URLの中の日本語（全角文字）を安全にエンコードする対策
            if xml_url.startswith("file:///"):
                path_part = xml_url[8:]
                encoded_url = "file:///" + urllib.parse.quote(path_part)
            elif xml_url.startswith("http://") or xml_url.startswith("https://"):
                scheme, netloc, path, query, fragment = urllib.parse.urlsplit(xml_url)
                path = urllib.parse.quote(path)
                encoded_url = urllib.parse.urlunsplit((scheme, netloc, path, query, fragment))
            else:
                encoded_url = urllib.parse.quote(xml_url, safe=":/")

            with urllib.request.urlopen(encoded_url) as response:
                xml_data = response.read()
                
            root = ET.fromstring(xml_data)
            
            for track in root.findall('Track'):
                page = int(track.find('Page').text) - 1 
                music_path = track.find('MusicPath').text
                self.playlist[page] = music_path
                
            self.playlist_pages = sorted(self.playlist.keys())
            print(f"XMLプレイリストの読み込みに成功しました。")
            
        except Exception as e:
            messagebox.showerror("XMLエラー", f"XMLの読み込みに失敗しました:\nURL: {xml_url}\nエラー: {e}")

    def create_widgets(self):
        """画面コントロールの配置"""
        top_frame = tk.Frame(self.root)
        top_frame.pack(fill="x", pady=5)

        btn_open = tk.Button(top_frame, text="PDFを開く", command=self.open_pdf)
        btn_open.pack(side="left", padx=10)

        # 「次のページ」ボタンを先に左詰め（pack）で配置
        self.btn_next = tk.Button(top_frame, text="◀ 次のページ (進む)", command=self.next_page, state="disabled")
        self.btn_next.pack(side="left", padx=5)

        self.lbl_page = tk.Label(top_frame, text="ページ: 0 / 0")
        self.lbl_page.pack(side="left", padx=10)

        # 「前のページ」ボタンを後に左詰め（pack）で配置
        self.btn_prev = tk.Button(top_frame, text="前のページ (戻る) ▶", command=self.prev_page, state="disabled")
        self.btn_prev.pack(side="left", padx=5)

        # ズーム調整バー
        zoom_frame = tk.Frame(top_frame)
        zoom_frame.pack(side="right", padx=10)
        lbl_zoom = tk.Label(zoom_frame, text="ズーム:")
        lbl_zoom.pack(side="left")
        self.zoom_slider = tk.Scale(zoom_frame, from_=50, to=300, orient="horizontal", length=100, showvalue=False, command=self.on_zoom_change)
        self.zoom_slider.set(100) 
        self.zoom_slider.pack(side="left")

        # 音量調節スライダー
        vol_frame = tk.Frame(top_frame)
        vol_frame.pack(side="right", padx=10)
        lbl_vol = tk.Label(vol_frame, text="音量:")
        lbl_vol.pack(side="left")
        self.vol_slider = tk.Scale(vol_frame, from_=0, to=100, orient="horizontal", length=100, showvalue=False, command=self.set_volume)
        self.vol_slider.set(50) 
        pygame.mixer.music.set_volume(0.5)
        self.vol_slider.pack(side="left")

        # 音楽情報・一時停止パネル
        music_frame = tk.Frame(self.root)
        music_frame.pack(fill="x", pady=2)

        self.lbl_music = tk.Label(music_frame, text="再生中の曲: なし", fg="blue", font=("MS Gothic", 10, "bold"))
        self.lbl_music.pack(side="left", padx=10)

        self.btn_play_pause = tk.Button(music_frame, text="一時停止", command=self.toggle_play_pause, state="disabled")
        self.btn_play_pause.pack(side="left", padx=5)

        # 画面の「一番下」に配置する右開き（右が1、左が最大）シークバーフレーム
        bottom_bar_frame = tk.Frame(self.root)
        bottom_bar_frame.pack(side="bottom", fill="x", padx=15, pady=5)

        # 右開き用に、左側に「最大ページ数」、右側に「1」のラベルを配置
        self.lbl_seekbar_end = tk.Label(bottom_bar_frame, text="1", font=("MS Gothic", 9, "bold"))
        self.lbl_seekbar_end.pack(side="left", padx=5)

        # スライダーの上部に表示される標準の数値を非表示にし、独自のページ番号を常時表示するラベル
        self.lbl_seekbar_val = tk.Label(bottom_bar_frame, text="ページ: 1", font=("MS Gothic", 10, "bold"), fg="darkgreen")
        self.lbl_seekbar_val.pack(side="bottom", pady=2)

        self.page_slider = tk.Scale(bottom_bar_frame, from_=1, to=1, orient="horizontal", showvalue=False, command=self.on_seekbar_change)
        self.page_slider.pack(side="left", fill="x", expand=True, padx=5)
        self.page_slider.config(state="disabled")

        self.lbl_seekbar_start = tk.Label(bottom_bar_frame, text="1", font=("MS Gothic", 9))
        self.lbl_seekbar_start.pack(side="left", padx=5)

        # スクロールバー付きのメイン表示エリア
        display_frame = tk.Frame(self.root)
        display_frame.pack(expand=True, fill="both", padx=10, pady=5)

        hbar = tk.Scrollbar(display_frame, orient="horizontal")
        hbar.pack(side="bottom", fill="x")
        vbar = tk.Scrollbar(display_frame, orient="vertical")
        vbar.pack(side="right", fill="y")

        self.canvas = tk.Canvas(display_frame, bg="gray", xscrollcommand=hbar.set, yscrollcommand=vbar.set)
        self.canvas.pack(expand=True, fill="both")
        
        hbar.config(command=self.canvas.xview)
        vbar.config(command=self.canvas.yview)

    def set_volume(self, val):
        volume = float(val) / 100.0
        pygame.mixer.music.set_volume(volume)

    def toggle_play_pause(self):
        if not self.current_music:
            return
        if self.is_paused:
            pygame.mixer.music.unpause()
            self.btn_play_pause.config(text="一時停止")
            self.is_paused = False
        else:
            pygame.mixer.music.pause()
            self.btn_play_pause.config(text="再生")
            self.is_paused = True

    def on_zoom_change(self, val):
        if self.doc and not self.is_loading:
            self.show_page()

    def open_pdf(self):
        """💡 メイン画面のちょうど真ん中にポップアップを表示する"""
        choice_window = tk.Toplevel(self.root)
        choice_window.title("PDFの読み込み方法")
        choice_window.resizable(False, False)
        
        # 💡【位置調整】メイン画面のサイズと位置を取得して真ん中を計算
        self.root.update_idletasks()
        root_w = self.root.winfo_width()
        root_h = self.root.winfo_height()
        root_x = self.root.winfo_x()
        root_y = self.root.winfo_y()
        
        win_w, win_h = 300, 120
        pos_x = root_x + (root_w - win_w) // 2
        pos_y = root_y + (root_h - win_h) // 2
        choice_window.geometry(f"{win_w}x{win_h}+{pos_x}+{pos_y}")
        
        choice_window.transient(self.root)
        choice_window.grab_set()
        
        lbl = tk.Label(choice_window, text="PDFの開く方法を選んでください", font=("MS Gothic", 10))
        lbl.pack(pady=15)
        
        btn_frame = tk.Frame(choice_window)
        btn_frame.pack(fill="x", padx=20)
        
        def select_local():
            choice_window.destroy()
            self.open_local_pdf()
            
        def select_net():
            choice_window.destroy()
            self.open_net_pdf()
            
        btn_local = tk.Button(btn_frame, text="ローカルから開く", command=select_local, width=13)
        btn_local.pack(side="left", padx=5)
        
        btn_net = tk.Button(btn_frame, text="ネット(URL)から開く", command=select_net, width=13)
        btn_net.pack(side="right", padx=5)

    def open_local_pdf(self):
        """従来のローカルファイルを開く処理"""
        file_path = filedialog.askopenfilename(filetypes=[("PDFファイル", "*.pdf")])
        if not file_path:
            return

        self.file_path = file_path
        self.doc = fitz.open(file_path)
        self.current_page = 0
        self.process_pdf_metadata(file_path)

    def open_net_pdf(self):
        """💡 サイズを大きくし、メイン画面の真ん中に表示する"""
        input_window = tk.Toplevel(self.root)
        input_window.title("URL入力")
        input_window.resizable(False, False)
        
        # 💡【位置調整】URL入力画面もメイン画面の真ん中に計算して配置
        self.root.update_idletasks()
        root_w = self.root.winfo_width()
        root_h = self.root.winfo_height()
        root_x = self.root.winfo_x()
        root_y = self.root.winfo_y()
        
        win_w, win_h = 550, 200
        pos_x = root_x + (root_w - win_w) // 2
        pos_y = root_y + (root_h - win_h) // 2
        input_window.geometry(f"{win_w}x{win_h}+{pos_x}+{pos_y}")
        
        input_window.transient(self.root)
        input_window.grab_set()

        lbl = tk.Label(input_window, text="PDFファイルのURLを入力してください:", font=("MS Gothic", 12, "bold"))
        lbl.pack(pady=15)

        entry_url = tk.Entry(input_window, font=("MS Gothic", 12), width=50)
        entry_url.pack(pady=10, padx=20)
        entry_url.focus_set()

        self.input_url_result = None

        def on_confirm(event=None):
            self.input_url_result = entry_url.get().strip()
            input_window.destroy()

        def on_cancel():
            input_window.destroy()

        btn_frame = tk.Frame(input_window)
        btn_frame.pack(pady=15)

        btn_ok = tk.Button(btn_frame, text="確定", command=on_confirm, width=12, font=("MS Gothic", 10))
        btn_ok.pack(side="left", padx=10)
        
        btn_cancel = tk.Button(btn_frame, text="キャンセル", command=on_cancel, width=12, font=("MS Gothic", 10))
        btn_cancel.pack(side="left", padx=10)

        entry_url.bind("<Return>", on_confirm)

        self.root.wait_window(input_window)

        url = self.input_url_result
        if not url:
            return

        if not (url.startswith("http://") or url.startswith("https://")):
            messagebox.showerror("エラー", "有効なURL（http:// または https://）を入力してください。")
            return

        try:
            scheme, netloc, path, query, fragment = urllib.parse.urlsplit(url)
            path = urllib.parse.quote(path)
            encoded_url = urllib.parse.urlunsplit((scheme, netloc, path, query, fragment))

            print(f"ネット上のPDFをダウンロード中: {url}")
            with urllib.request.urlopen(encoded_url) as response:
                pdf_data = response.read()
                
            temp_dir = tempfile.gettempdir()
            temp_pdf_path = os.path.join(temp_dir, "net_novel_temp.pdf")
            with open(temp_pdf_path, "wb") as f:
                f.write(pdf_data)

            self.file_path = url  
            self.doc = fitz.open(temp_pdf_path)
            self.current_page = 0
            
            self.process_pdf_metadata(url)
            
        except Exception as e:
            messagebox.showerror("ダウンロードエラー", f"PDFの取得に失敗しました:\n{e}")

    def process_pdf_metadata(self, base_path):
        """メタデータからXMLを読み込む共通処理"""
        self.playlist = {}
        self.playlist_pages = []

        metadata = self.doc.metadata
        xml_url = metadata.get("keywords", "").strip() if metadata else ""

        if not xml_url and not base_path.startswith("http"):
            base_path_parts = base_path.rsplit(".", 1)
            xml_path = base_path_parts + ".xml"
            if os.path.exists(xml_path):
                xml_url = xml_path

        if xml_url:
            if not (xml_url.startswith("http://") or xml_url.startswith("https://") or xml_url.startswith("file://")):
                abs_path = os.path.abspath(xml_url)
                xml_url = f"file:///{abs_path.replace(os.sep, '/')}"
            
            self.load_playlist_xml(xml_url)
        else:
            messagebox.showwarning(
                "設定なし", 
                "PDFのプロパティ（キーワード）にXMLのURLが見つかりませんでした。\n音楽なしで再生します。"
            )

        self.root.after(100, self.delayed_init)

    def delayed_init(self):
        """表示する前に栞データを読み込み、シークバーを設定"""
        self.load_bookmark()
        
        if self.doc:
            total_pages = len(self.doc)
            self.is_loading = True
            self.page_slider.config(state="normal", from_=1, to=total_pages)
            self.lbl_seekbar_end.config(text=str(total_pages))
            self.lbl_seekbar_start.config(text="1")
            self.is_loading = False
        
        self.fit_to_screen()
        self.show_page()
        self.update_buttons()
        self.btn_play_pause.config(state="normal")

    def fit_to_screen(self):
        if not self.doc:
            return
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
        if canvas_w < 10: canvas_w = self.root.winfo_width() - 40
        if canvas_h < 10: canvas_h = self.root.winfo_height() - 170 

        page = self.doc.load_page(self.current_page)
        pdf_rect = page.rect

        zoom_w = (canvas_w - 30) / pdf_rect.width
        zoom_h = (canvas_h - 30) / pdf_rect.height
        best_zoom = min(zoom_w, zoom_h)

        zoom_percent = int(best_zoom * 100)
        zoom_percent = max(50, min(300, zoom_percent))

        self.is_loading = True
        self.zoom_slider.set(zoom_percent)
        self.is_loading = False

    def show_page(self):
        if not self.doc:
            return

        page = self.doc.load_page(self.current_page)
        zoom_percent = self.zoom_slider.get()
        zoom_factor = zoom_percent / 100.0
        
        zoom_matrix = fitz.Matrix(zoom_factor, zoom_factor)
        pix = page.get_pixmap(matrix=zoom_matrix)
        
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        self.photo = ImageTk.PhotoImage(img)
        
        self.canvas.delete("all")

        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()

        scroll_w = max(pix.width, canvas_w)
        scroll_h = max(pix.height, canvas_h)
        self.canvas.config(scrollregion=(0, 0, scroll_w, scroll_h))

        pos_x = canvas_w / 2 if pix.width < canvas_w else pix.width / 2
        pos_y = canvas_h / 2 if pix.height < canvas_h else pix.height / 2

        self.canvas.create_image(pos_x, pos_y, image=self.photo, anchor="center")

        self.manage_music()
        self.lbl_page.config(text=f"ページ: {self.current_page + 1} / {len(self.doc)}")

    def on_resize(self, event):
        if self.doc and event.widget == self.root:
            if self.resize_timer:
                self.root.after_cancel(self.resize_timer)
            self.resize_timer = self.root.after(200, self.show_page)

    def manage_music(self):
        """💡 音楽ファイルがネット上のURLであっても、ファイルロックを回避して自動ダウンロード・再生する"""
        target_music = None
        
        if self.playlist_pages:
            idx = bisect.bisect_right(self.playlist_pages, self.current_page)
            if idx > 0:
                target_page = self.playlist_pages[idx - 1]
                target_music = self.playlist[target_page]

        if target_music:
            if target_music != self.current_music:
                # 💡 再生中の曲名を画面に表示（URLならファイル名部分を切り出す）
                music_name = urllib.parse.unquote(target_music.split("/")[-1])
                self.lbl_music.config(text=f"再生中の曲: {music_name}")
                
                try:
                    # 曲の切り替え時に滑らかにフェードアウト
                    pygame.mixer.music.fadeout(1000)
                    
                    # 💡【ネット上のURL（http:// または https://）の場合】
                    if target_music.startswith("http://") or target_music.startswith("https://"):
                        # 日本語URL（全角文字）対策のエンコード
                        scheme, netloc, path, query, fragment = urllib.parse.urlsplit(target_music)
                        path = urllib.parse.quote(path)
                        encoded_url = urllib.parse.urlunsplit((scheme, netloc, path, query, fragment))
                        
                        print(f"BGMをダウンロード中: {target_music}")
                        with urllib.request.urlopen(encoded_url) as response:
                            music_data = response.read()
                        
                        # 💡【最重要バグ対策】
                        # pygameが古いファイルをロックして上書きエラーを起こすのを防ぐため、
                        # 毎回全く別のテンポラリファイル（一時ファイル）を自動生成させてロックを回避します
                        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as temp_file:
                            temp_file.write(music_data)
                            play_path = temp_file.name # OSが生成したランダムな安全パス
                    else:
                        # 従来のローカルファイルの場合
                        if not os.path.exists(target_music):
                            self.lbl_music.config(text=f"エラー: {music_name} が見つかりません")
                            return
                        play_path = target_music

                    # 音楽の読み込みと再生
                    pygame.mixer.music.load(play_path)
                    self.current_music = target_music  # オリジナルのURL/パスを保持

                    if self.is_paused:
                        pygame.mixer.music.play(-1)
                        pygame.mixer.music.pause()
                    else:
                        pygame.mixer.music.play(-1, fade_ms=1000)
                        
                except Exception as e:
                    self.lbl_music.config(text=f"音楽読み込みエラー: {music_name}")
                    print(f"音楽再生エラー: {e}")
        else:
            pygame.mixer.music.fadeout(1000)
            self.current_music = ""
            self.lbl_music.config(text="再生中の曲: なし")

    def next_page(self):
        if self.doc and self.current_page < len(self.doc) - 1:
            self.current_page += 1
            self.show_page()
            self.update_buttons()

    def prev_page(self):
        if self.doc and self.current_page > 0:
            self.current_page -= 1
            self.show_page()
            self.update_buttons()

    # シークバーが操作されたときのジャンプ処理（右開き計算）
    def on_seekbar_change(self, val):
        if self.doc and not self.is_loading:
            total = len(self.doc)
            slider_val = int(val)
            target_page = total - slider_val
            self.lbl_seekbar_val.config(text=f"ページ: {target_page + 1}")
            if target_page != self.current_page:
                self.current_page = target_page
                self.show_page()
                self.update_buttons()

    # ボタンとシークバーの同期処理
    def update_buttons(self):
        if not self.doc:
            return

        if self.current_page == 0:
            self.btn_prev.config(state="disabled")
        else:
            self.btn_prev.config(state="normal")

        if self.current_page == len(self.doc) - 1:
            self.btn_next.config(state="disabled")
        else:
            self.btn_next.config(state="normal")

        total = len(self.doc)
        slider_pos = total - self.current_page
        
        self.is_loading = True  
        self.page_slider.set(slider_pos)
        self.lbl_seekbar_val.config(text=f"ページ: {self.current_page + 1}")
        self.is_loading = False

    # ★【新設】タッチが開始された瞬間の座標を記録
    def on_touch_start(self, event):
        self.touch_start_x = event.x
        self.touch_start_y = event.y

    # ★【新設】指が離されたときにスワイプ距離を計算してページをめくる
    def on_touch_end(self, event):
        if not self.doc:
            return
            
        delta_x = event.x - self.touch_start_x
        delta_y = event.y - self.touch_start_y
        
        # 誤作動防止のため、横方向への移動が70ピクセル以上のときだけ実行
        if abs(delta_x) > 70 and abs(delta_x) > abs(delta_y):
            if delta_x > 0:
                # 右へのスワイプ ＝ 前のページ（戻る）
                self.prev_page()
            else:
                # 左へのスワイプ ＝ 次のページ（進む）
                self.next_page()

    # ★【新設】2本指のピンチジェスチャーやトラックパッドによるズーム操作
    def on_pinch_zoom(self, event):
        if not self.doc:
            return
            
        current_zoom = self.zoom_slider.get()
        # Windowsのジェスチャーイベントの回転方向に応じてズーム値を上下させる
        if event.delta > 0:
            new_zoom = min(300, current_zoom + 10)
        else:
            new_zoom = max(50, current_zoom - 10)
            
        if new_zoom != current_zoom:
            self.zoom_slider.set(new_zoom) # スライダーを動かすことで自動的にshow_pageが走ります

    # ★【バグ修正完了】ファイル名に基づいた栞テキストファイルのパスを返す
    def get_bookmark_path(self):
        if not self.file_path:
            return None
        
        if self.file_path.startswith("http://") or self.file_path.startswith("https://"):
            import hashlib
            url_hash = hashlib.md5(self.file_path.encode('utf-8')).hexdigest()
            temp_dir = tempfile.gettempdir()
            return os.path.join(temp_dir, f"bookmark_{url_hash}.txt")
        else:
            base_path_parts = self.file_path.rsplit(".", 1)
            # リストの最初の要素（拡張子なしパス）をしっかり指定して結合
            return f"{base_path_parts[0]}_bookmark.txt"

    def save_bookmark(self):
        """現在のページをテキストファイルに保存する"""
        bookmark_path = self.get_bookmark_path()
        if bookmark_path:
            try:
                with open(bookmark_path, "w", encoding="utf-8") as f:
                    f.write(str(self.current_page))
                print(f"栞を保存しました: {bookmark_path} (ページ: {self.current_page + 1})")
            except Exception as e:
                print(f"栞の保存に失敗しました: {e}")

    def load_bookmark(self):
        """栞テキストファイルがあれば読み込んでページを移動する"""
        bookmark_path = self.get_bookmark_path()
        if bookmark_path and os.path.exists(bookmark_path):
            try:
                with open(bookmark_path, "r", encoding="utf-8") as f:
                    saved_page = int(f.read().strip())
                    if self.doc and 0 <= saved_page < len(self.doc):
                        self.current_page = saved_page
                        print(f"栞から再開します: {self.current_page + 1} ページ目")
            except Exception as e:
                print(f"栞の読み込みに失敗しました: {e}")

    def on_closing(self):
        """アプリ終了時に栞を保存し、pygameを解放して閉じる"""
        if self.doc:
            self.save_bookmark()
        
        try:
            pygame.mixer.music.stop()
            pygame.mixer.quit()
        except Exception:
            pass
            
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = MusicPDFViewer(root)
    root.mainloop()
