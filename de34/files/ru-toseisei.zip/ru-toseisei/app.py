import os
import re

from flask import Flask, render_template, request
from openai import OpenAI

app = Flask(__name__)

client = OpenAI(api_key="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")

def clean_result(text):
    """Markdown記号を軽く除去"""

    text = re.sub(r"^#+\s?", "", text, flags=re.MULTILINE)
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"^\-\s", "• ", text, flags=re.MULTILINE)

    return text.strip()


def generate_route(
    places,
    transport_mode,
    title,
    mood
):

    place_text = "\n".join(
        f"- {p}" for p in places
    )

    transport_text = {
        "walk": "徒歩メイン",
        "train": "電車メイン",
        "car": "車移動メイン",
        "mixed": "状況に応じて最適な移動手段"
    }.get(
        transport_mode,
        "状況に応じて最適な移動手段"
    )

    mood_text = {
        "normal": "バランス重視",
        "photo": "写真スポット重視",
        "gourmet": "グルメ重視",
        "relax": "ゆるめ観光"
    }.get(
        mood,
        "バランス重視"
    )

    prompt = f"""
あなたは旅行プランナーです。

以下の情報を元に、
自然で回りやすいルートを作成してください。

テーマ:
{title if title else '未指定'}

移動手段:
{transport_text}

プランスタイル:
{mood_text}

場所一覧:
{place_text}

ルール:
- 効率よく回れる順番に整理する
- 各場所への移動方法を書く
- 時間は移動時間のみでよい(滞在時間等の記載はいらない)
- 見やすくまとめる
- 周辺にある良い場所があれば記載することも可
- Markdown記号(#や**)は禁止
- 最後に語りかけない
- 「楽しんでください」は不要
- 必要なら移動時間も書く
- 自然なお出かけプラン風にまとめる
"""

    response = client.chat.completions.create(
        model="gpt-4.1-mini",

        messages=[
            {
                "role": "system",
                "content":
                "あなたは観光ルートを作る専門アシスタントです。"
            },
            {
                "role": "user",
                "content": prompt
            }
        ],

        temperature=0.7,
    )

    result = response.choices[0].message.content

    return clean_result(result)


@app.route("/", methods=["GET", "POST"])
def index():

    if request.method == "POST":

        places = request.form.getlist("places")

        places = [
            p.strip()
            for p in places
            if p.strip()
        ]

        transport_mode = request.form.get(
            "transport_mode"
        )

        title = request.form.get("title")

        mood = request.form.get("mood")

        if not places:

            return render_template(
                "index.html",
                error="場所を1つ以上入力してください"
            )

        result = generate_route(
            places,
            transport_mode,
            title,
            mood
        )

        return render_template(
            "result.html",
            result=result,
            places=places
        )

    return render_template("index.html")


if __name__ == "__main__":

    port = int(
        os.environ.get("PORT", 8080)
    )

    app.run(
        host="0.0.0.0",
        port=port
    )