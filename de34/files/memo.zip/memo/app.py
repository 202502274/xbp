import os
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
# 画像の保存先設定
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 最大16MB
DATA_FILE = 'data.json'

# 必要なフォルダを自動作成
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def load_data():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_data(data):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

@app.route('/')
def index():
    data = load_data()
    data.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return render_template('index.html', entries=data)

@app.route('/add', methods=['POST'])
def add():
    entry_type = request.form.get('type', 'memo')
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    
    if not title: return redirect(url_for('index'))

    # 画像保存処理[cite: 3]
    image_filename = None
    if 'image' in request.files:
        file = request.files['image']
        if file and file.filename != '':
            filename = secure_filename(f"{datetime.now().timestamp()}_{file.filename}")
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            image_filename = filename

    data = load_data()
    new_entry = {
        'id': str(datetime.now().timestamp()),
        'type': entry_type,
        'title': title,
        'content': content,
        'image': image_filename,
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'is_done': False
    }
    data.append(new_entry)
    save_data(data)
    return redirect(url_for('index'))

@app.route('/edit/<entry_id>', methods=['GET', 'POST'])
def edit(entry_id):
    data = load_data()
    entry = next((e for e in data if e['id'] == entry_id), None)
    if not entry: return redirect(url_for('index'))

    if request.method == 'POST':
        entry['title'] = request.form.get('title', '').strip()
        entry['content'] = request.form.get('content', '').strip()
        entry['type'] = request.form.get('type', 'memo')
        save_data(data)
        return redirect(url_for('index'))
    
    return render_template('edit.html', entry=entry)

@app.route('/delete/<entry_id>', methods=['POST'])
def delete(entry_id):
    data = load_data()
    data = [e for e in data if e['id'] != entry_id]
    save_data(data)
    return redirect(url_for('index'))

@app.route('/toggle/<entry_id>', methods=['POST'])
def toggle(entry_id):
    data = load_data()
    for e in data:
        if e['id'] == entry_id:
            e['is_done'] = not e.get('is_done', False)
            break
    save_data(data)
    return redirect(url_for('index'))

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    app.run(host="0.0.0.0", port=port)